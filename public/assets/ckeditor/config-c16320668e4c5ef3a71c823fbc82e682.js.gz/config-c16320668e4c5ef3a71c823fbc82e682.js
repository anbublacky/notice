CKEDITOR.config.toolbar_mini =
    [
        ['Format'],
        ['Bold','Italic'],
        ['NumberedList','BulletedList'],
        ['Link','Unlink'],
        ['Image','Table','HorizontalRule'],
    ];
